document.addEventListener("mousemove", (e) => {
  const cursor = document.querySelector(".mermaid-cursor");
  cursor.style.left = e.pageX + "px";
  cursor.style.top = e.pageY + "px";
});

function goHome() {
  alert("Back to LiquidJane Home!");
}
